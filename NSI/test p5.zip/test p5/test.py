from p5 import *
# variables globales
liste=0
x_monster=220
y_monster=150
pas_monster=15
liste_impacts=[]
tempo=0
monster_en_vie=True
tempo=False
fond=None
viseur=None
monster=None
impact=None
monsterMort=None

def setup():
    global fond,viseur,monster,impact,monsterMort
    fond = load_image("fond.png")
    viseur=load_image("viseur.png")
    monster=load_image("monster.png")
    impact=load_image("impact.png")
    monsterMort=load_image("monsterMort.png")
    size(512, 287)
    

def draw():
    global liste,x_monster,pas_monster,y_monster,liste_impacts,monster_en_vie,tempo
    # déplacement du monstre
    if monster_en_vie:
        if x_monster>512-monster.width:
            pas_monster = -pas_monster
        if x_monster<0:
            pas_monster=-pas_monster
        x_monster=x_monster+pas_monster
        
    if mouse_is_pressed : 
        if tempo==False:
            tempo=True #tempo pour éviter les tirs en rafale
            x=mouse_x
            y=mouse_y
            liste_impacts.append((x-impact.width/2,y-impact.height/2))
            if x_monster+10<x<x_monster+monster.width-10 and y_monster+10<y<y_monster+monster.height-10:
                monster_en_vie=False
                ptint("coucou")
    else: # si la souris n'est plus pressée
        tempo=False
    
    # construction de l'image

    background(fond)
    for imp in liste_impacts:
        image(impact,imp[0],imp[1])
    if monster_en_vie:
        image(monster,x_monster,y_monster)
    else:
        image(monsterMort,x_monster,y_monster+30)
    image(viseur,mouse_x - viseur.width/2,mouse_y-viseur.height/2)


if __name__ == '__main__':
    run()